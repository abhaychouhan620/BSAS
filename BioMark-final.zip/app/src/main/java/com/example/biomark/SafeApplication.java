package com.example.biomark;

import android.app.Application;
import android.content.res.Resources;
import android.util.Log;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import java.io.InputStream;
import org.json.JSONObject;
import java.io.IOException;

/**
 * SafeApplication initializes Firebase only if possible. If google-services.json is absent,
 * it initializes Firebase with placeholder options to avoid runtime crashes during demo.
 */
public class SafeApplication extends Application {
    private static final String TAG = "SafeApplication";
    @Override
    public void onCreate() {
        super.onCreate();
        try {
            // Try to initialize Firebase normally
            FirebaseApp.initializeApp(this);
            Log.i(TAG, "Firebase initialized normally (if configuration present).");
        } catch (Exception e) {
            Log.w(TAG, "Normal Firebase init failed: " + e.getMessage() + " -- attempting safe init.");
            try {
                // Safe fallback: initialize with placeholder options to avoid IllegalStateException
                FirebaseOptions options = new FirebaseOptions.Builder()
                        .setApplicationId("1:000000000000:android:000000000000") // placeholder
                        .setApiKey("PLACEHOLDER_API_KEY")
                        .setDatabaseUrl("https://PLACEHOLDER.firebaseio.com")
                        .setStorageBucket("PLACEHOLDER.appspot.com")
                        .build();
                FirebaseApp.initializeApp(this, options);
                Log.i(TAG, "Firebase initialized with placeholder options.");
            } catch (Exception ex) {
                Log.e(TAG, "Safe Firebase init failed: " + ex.getMessage());
            }
        }
    }
}